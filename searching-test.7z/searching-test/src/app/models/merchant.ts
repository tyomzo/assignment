export interface Merchant {
  id: string;
  name: string;
  vat: string;
}
